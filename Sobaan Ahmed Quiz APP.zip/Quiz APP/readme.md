# QuizApp

A functional quiz app built with HTML, CSS, and JavaScript.

---

## File Structure

quizapp/
├── index.html
├── style.css
├── script.js
└── README.md

---

## Features

- 10 questions with 4 options each
- Selected option highlights in cyan only — no right/wrong hints during quiz
- Progress bar tracking current question
- Final score with grade and message
- Full answer breakdown at the end with correct answers revealed
- Restart without page reload

---

## Screens

| Screen | Description |
|--------|-------------|
| Start  | Welcome screen with start button |
| Quiz   | One question at a time with 4 options |
| Result | Score, grade, and per-question breakdown |

---

## Grading Scale

| Score | Grade |
|-------|-------|
| 10/10 | Perfect! |
| 8–9   | Excellent! |
| 6–7   | Good Job! |
| 4–5   | Keep Going! |
| 0–3   | Try Again! |

---

## How to Run

Open index.html in any browser. No build step, no server needed.

---

## How It Works

Three state variables drive everything:

| Variable | Purpose |
|----------|---------|
| currentIndex | Tracks which question is active |
| score | Counts correct answers |
| userAnswers | Stores all selected answers for breakdown |

Example flow:
1. startQuiz() → resets state, shows quiz screen
2. loadQuestion() → renders question and 4 option buttons
3. selectAnswer(i) → marks selected in cyan, no correct/wrong shown
4. nextQuestion() → advances index or calls showResults()
5. showResults() → calculates grade, reveals correct answers in breakdown