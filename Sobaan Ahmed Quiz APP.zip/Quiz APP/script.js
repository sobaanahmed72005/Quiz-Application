const questions = [
  {
    q: "What does HTML stand for?",
    options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Logic", "Home Tool Markup Language"],
    answer: 0
  },
  {
    q: "Which language is used to style web pages?",
    options: ["Python", "Java", "CSS", "C++"],
    answer: 2
  },
  {
    q: "What does CSS stand for?",
    options: ["Computer Style Sheets", "Cascading Style Sheets", "Creative Style System", "Colorful Style Syntax"],
    answer: 1
  },
  {
    q: "Which symbol is used for single-line comments in JavaScript?",
    options: ["#", "//", "/* */", "--"],
    answer: 1
  },
  {
    q: "What is the correct way to declare a variable in JavaScript?",
    options: ["var myVar;", "variable myVar;", "v myVar;", "declare myVar;"],
    answer: 0
  },
  {
    q: "Which HTML tag is used to link an external CSS file?",
    options: ["<style>", "<css>", "<link>", "<script>"],
    answer: 2
  },
  {
    q: "What does the 'typeof' operator do in JavaScript?",
    options: ["Deletes a variable", "Returns the type of a value", "Converts a value to string", "Checks equality"],
    answer: 1
  },
  {
    q: "Which property is used to change text color in CSS?",
    options: ["font-color", "text-color", "color", "foreground"],
    answer: 2
  },
  {
    q: "What is the output of: console.log(2 + '2') in JavaScript?",
    options: ["4", "22", "NaN", "Error"],
    answer: 1
  },
  {
    q: "Which HTML attribute is used to define inline styles?",
    options: ["class", "styles", "style", "font"],
    answer: 2
  }
];

let currentIndex = 0;
let score = 0;
let answered = false;
let userAnswers = [];

function startQuiz() {
  currentIndex = 0;
  score = 0;
  answered = false;
  userAnswers = [];
  show('quizScreen');
  loadQuestion();
}

function loadQuestion() {
  answered = false;
  const q = questions[currentIndex];
  document.getElementById('qNum').textContent = currentIndex + 1;
  document.getElementById('progressFill').style.width = ((currentIndex + 1) / questions.length * 100) + '%';
  document.getElementById('questionText').textContent = q.q;
  document.getElementById('nextBtn').classList.add('hidden');

  const container = document.getElementById('optionsContainer');
  container.innerHTML = '';

  q.options.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'option';
    btn.textContent = opt;
    btn.onclick = () => selectAnswer(i);
    container.appendChild(btn);
  });
}

function selectAnswer(selected) {
  if (answered) return;
  answered = true;

  const opts = document.querySelectorAll('.option');
  opts.forEach(o => o.disabled = true);
  opts[selected].classList.add('selected');

  userAnswers.push({
    q: questions[currentIndex].q,
    selected,
    correct: questions[currentIndex].answer,
    options: questions[currentIndex].options
  });

  document.getElementById('nextBtn').classList.remove('hidden');
}

function nextQuestion() {
  currentIndex++;
  if (currentIndex < questions.length) {
    loadQuestion();
  } else {
    showResults();
  }
}

function showResults() {
  score = userAnswers.filter(a => a.selected === a.correct).length;
  show('resultScreen');
  document.getElementById('scoreText').textContent = score + '/' + questions.length;

  const pct = (score / questions.length) * 100;
  let grade, msg;

  if (pct === 100)    { grade = 'Perfect!';    msg = 'Flawless — you nailed every single question.'; }
  else if (pct >= 80) { grade = 'Excellent!';  msg = 'Great work, you really know your stuff.'; }
  else if (pct >= 60) { grade = 'Good Job!';   msg = 'Solid effort — a little more practice and you\'ll ace it.'; }
  else if (pct >= 40) { grade = 'Keep Going!'; msg = 'Not bad — review the topics and try again.'; }
  else                { grade = 'Try Again!';  msg = 'Don\'t give up — every attempt makes you better.'; }

  document.getElementById('gradeText').textContent = grade;
  document.getElementById('gradeMsg').textContent  = msg;

  const breakdown = document.getElementById('breakdown');
  breakdown.innerHTML = '';

  userAnswers.forEach((a, i) => {
    const div = document.createElement('div');
    div.className = 'breakdown-item ' + (a.selected === a.correct ? 'correct' : 'wrong');
    div.innerHTML = `
      <div class="bi-q">Q${i + 1}: ${a.q}</div>
      <div class="bi-a">Your answer: ${a.options[a.selected]}</div>
      ${a.selected !== a.correct ? `<div class="bi-a" style="color:#00c97a">Correct: ${a.options[a.correct]}</div>` : ''}
    `;
    breakdown.appendChild(div);
  });
}

function restartQuiz() {
  show('startScreen');
}

function show(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}